// Quantaureum: SES lockdown shim disabled
// Original: 217KB SES shim that defines globalThis.lockdown
// Reason: lockdown() freezes all JS intrinsics making prototypes non-writable,
// causing "Cannot assign to read only property" errors in bundled dependencies
// (e.g. Buffer.prototype.toLocaleString assignment in sentry-install.js, common-8.js)
// lockdown function is provided as no-op in lockdown-run.js instead
