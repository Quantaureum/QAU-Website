// Make all "object" and "function" own properties of globalThis
// non-configurable and non-writable, when possible.
// Quantaureum: Skip entirely when lockdown() was not called
if (globalThis.__QUANTAUREUM_SKIP_LOCKDOWN) {
  // lockdown() was skipped, skip protection too
} else {
try {
  (function protectIntrinsics() {
    const lmre =
      /LavaMoat - property "[A-Za-z0-9]*" of globalThis is inaccessible under scuttling mode/u;

    const namedIntrinsics = Reflect.ownKeys(new Compartment().globalThis);

    const shouldHardenManually = new Set(['eval', 'Function', 'Symbol']);

    const globalProperties = new Set([
      ...namedIntrinsics,
    ]);

    globalProperties.forEach((propertyName) => {
      const descriptor = Reflect.getOwnPropertyDescriptor(
        globalThis,
        propertyName,
      );

      if (descriptor) {
        if (descriptor.configurable) {
          if (hasAccessor(descriptor)) {
            Object.defineProperty(globalThis, propertyName, {
              configurable: false,
            });
          } else {
            Object.defineProperty(globalThis, propertyName, {
              configurable: false,
              writable: false,
            });
          }
        }

        if (shouldHardenManually.has(propertyName)) {
          try {
            harden(globalThis[propertyName]);
          } catch (err) {
            if (!lmre.test(err.message)) {
              throw err;
            }
            console.warn(
              `Property ${propertyName} will not be hardened`,
              `because it is scuttled by LavaMoat protection.`,
              `Visit https://github.com/LavaMoat/LavaMoat/pull/360 to learn more.`,
            );
          }
        }
      }
    });

    function hasAccessor(descriptor) {
      return 'set' in descriptor || 'get' in descriptor;
    }
  })();
} catch (error) {
  console.error('Protecting intrinsics failed:', error);
  if (globalThis.sentry && globalThis.sentry.captureException) {
    globalThis.sentry.captureException(
      new Error(`Protecting intrinsics failed: ${error.message}`),
    );
  }
}
}
