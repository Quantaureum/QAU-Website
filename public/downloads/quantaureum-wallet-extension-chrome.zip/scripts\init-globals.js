/**
 * This script add properties in globalThis and initialises them with undefined.
 * This is workaround needed to avoid error in dependencies expecting to be run in a browser
 * these dependencies are not available to service worker in MV3.
 */

// eslint-disable-next-line import/unambiguous
const keys = [
  'XMLHttpRequest',
  'requestAnimationFrame',
  'cancelAnimationFrame',
];

keys.forEach((key) => {
  if (!Reflect.has(globalThis, key)) {
    if (key === 'requestAnimationFrame') {
      globalThis[key] = (cb) => setTimeout(cb, 0);
    } else if (key === 'cancelAnimationFrame') {
      globalThis[key] = (id) => clearTimeout(id);
    } else {
      globalThis[key] = undefined;
    }
  }
});

if (!Reflect.has(globalThis, 'window')) {
  globalThis.window = globalThis;
}
