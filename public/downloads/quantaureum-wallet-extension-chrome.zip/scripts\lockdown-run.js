// Quantaureum: SES lockdown disabled
// Reason: lockdown() freezes all JS intrinsics causing "Cannot assign to read only property"
// errors in bundled dependencies (zxing, jss, lodash, call-bind, etc.)
// lockdown and harden are provided as no-ops

// Set flag so lockdown-more.js skips protecting intrinsics
globalThis.__QUANTAUREUM_SKIP_LOCKDOWN = true;

if (typeof globalThis.lockdown !== 'function') {
  globalThis.lockdown = function lockdown(_options) {
    // no-op: do not freeze prototypes
  };
}

if (typeof globalThis.harden !== 'function') {
  globalThis.harden = function harden(obj) {
    return obj;
  };
}

// Do NOT call lockdown() - this would freeze all prototypes