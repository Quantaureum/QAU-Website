/**
 * Dilithium3 WASM loader for Service Worker (Go circl-based)
 *
 * Instantiates the dilithium3-circl.wasm module compiled from
 * cloudflare/circl/sign/dilithium/mode3.
 *
 * IMPORTANT: wasm_exec.js (Go runtime) is loaded BEFORE this script by
 * app-init.js via top-level importScripts. Chrome MV3 restricts importScripts
 * to the service worker's top-level script only — nested calls are not allowed.
 *
 * All references to browser globals must be captured synchronously at the top
 * level, because the async IIFE resumes AFTER LavaMoat scuttling is active.
 */

// Capture references BEFORE LavaMoat scuttling makes them inaccessible.
// This script is loaded via importScripts in the Service Worker top-level scope.
// The async IIFE below resumes AFTER LavaMoat/Snow scuttling is active, so all
// globalThis property reads MUST happen synchronously here at the top level.
const _capturedGlobalThis = globalThis;
const _Go = _capturedGlobalThis.Go;
const _fetch = _capturedGlobalThis.fetch.bind(_capturedGlobalThis);
const _chrome = _capturedGlobalThis.chrome;
const _WebAssembly = _capturedGlobalThis.WebAssembly;
const _setTimeout = _capturedGlobalThis.setTimeout.bind(_capturedGlobalThis);
const _crypto = _capturedGlobalThis.crypto;
// Capture DILITHIUM_WASM_HASH synchronously — it is set by app-init.js before
// this script loads, but LavaMoat scuttling makes it inaccessible inside the
// async IIFE. Reading it here (before any await) avoids the scuttling error:
//   "LavaMoat - property 'DILITHIUM_WASM_HASH' of globalThis is inaccessible
//    under scuttling mode"
const _capturedDilithiumWasmHash = _capturedGlobalThis.DILITHIUM_WASM_HASH || '';

// Step tracker visible to wasm-loader.ts via Go._realGlobalThis bridge
_capturedGlobalThis._dilithium3_step = 'captured';

(async function initDilithium3() {
  try {
    if (typeof _Go !== 'function') {
      throw new Error('Go runtime is unavailable. Ensure wasm_exec.js loads before dilithium-loader.js');
    }

    _capturedGlobalThis._dilithium3_step = 'creating_go';
    const go = new _Go();

    // Capture Go exit code for diagnostics
    go.exit = (code) => {
      _capturedGlobalThis._dilithium3_error = 'go_exit:' + code;
      if (code !== 0) {
        console.error('[Quantaureum] Go WASM exited with code:', code);
      }
    };

    _capturedGlobalThis._dilithium3_step = 'fetching';
    const wasmUrl = _chrome.runtime.getURL('scripts/dilithium3-circl.wasm');
    const response = await _fetch(wasmUrl);
    if (!response.ok) {
      throw new Error('Failed to fetch dilithium3-circl.wasm: ' + response.status);
    }

    _capturedGlobalThis._dilithium3_step = 'arrayBuffer';
    const wasmBytes = await response.arrayBuffer();

    // WASM integrity check: verify SHA-256 hash before instantiation to prevent
    // supply-chain attacks. The expected hash can be set as a global variable
    // DILITHIUM_WASM_HASH (e.g. via app-init.js which reads process.env at build time)
    // or will be read from self.DILITHIUM_WASM_HASH. In dev/test, an empty
    // hash skips the check; in production, a missing hash is fatal.
    _capturedGlobalThis._dilithium3_step = 'integrity_check';
    // Use the synchronously captured hash value instead of reading from
    // self/globalThis — LavaMoat scuttling blocks those reads inside async code.
    var expectedHash = _capturedDilithiumWasmHash;
    if (expectedHash) {
      var hashBuffer = await _crypto.subtle.digest('SHA-256', wasmBytes);
      var hashHex = [...new Uint8Array(hashBuffer)].map(function(b) { return b.toString(16).padStart(2, '0'); }).join('');
      if (hashHex !== expectedHash.toLowerCase()) {
        throw new Error('[CRITICAL] dilithium3-circl.wasm integrity check failed. The WASM binary may have been tampered with.');
      }
      console.info('[Quantaureum] Dilithium3 WASM integrity check passed.');
    } else {
      // In production, DILITHIUM_WASM_HASH MUST be set via build-time injection.
      // SECURITY (audit 2026-06-24, L-1): Use the build-time NODE_ENV constant
      // instead of unreliable runtime heuristics (chrome.runtime.id, manifest
      // name, update_url) which can be spoofed or misidentified.
      var isProduction = typeof process !== 'undefined' && process.env && process.env.NODE_ENV === 'production';

      if (isProduction) {
        console.error(
          '[CRITICAL] DILITHIUM_WASM_HASH not configured. ' +
          'WASM integrity verification is DISABLED. ' +
          'This is a security risk in production. ' +
          'Set DILITHIUM_WASM_HASH in builds.yml and rebuild.'
        );
        throw new Error(
          '[CRITICAL] DILITHIUM_WASM_HASH not set in production. ' +
          'Refusing to load Dilithium3 WASM without integrity verification. ' +
          'Set DILITHIUM_WASM_HASH in builds.yml and rebuild.'
        );
      } else {
        console.warn(
          '[Quantaureum] DILITHIUM_WASM_HASH not set. ' +
          'WASM integrity verification will be skipped. ' +
          'This is acceptable in development but MUST be configured for production.'
        );
      }
    }

    _capturedGlobalThis._dilithium3_step = 'instantiating';
    const result = await _WebAssembly.instantiate(wasmBytes, go.importObject);

    _capturedGlobalThis._dilithium3_step = 'running';
    // Don't await go.run() — it blocks until Go program exits.
    // Catch errors from the async run separately.
    go.run(result.instance).catch((err) => {
      _capturedGlobalThis._dilithium3_error = 'run_err:' + (err && err.message ? err.message : String(err));
      console.error('[Quantaureum] go.run() error:', err);
    });

    // Check immediately after run starts — Go registers globals synchronously in _start()
    if (_capturedGlobalThis._dilithium3_ready) {
      _capturedGlobalThis._dilithium3_step = 'done_sync';
      console.info('[Quantaureum] Dilithium3 circl WASM loaded (sync).');
    } else {
      _capturedGlobalThis._dilithium3_step = 'waiting';
      let retries = 0;
      while (!_capturedGlobalThis._dilithium3_ready && retries < 50) {
        await new Promise((r) => _setTimeout(r, 50));
        retries++;
      }
    }

    if (_capturedGlobalThis._dilithium3_ready) {
      _capturedGlobalThis._dilithium3_step = 'done';
      console.info('[Quantaureum] Dilithium3 circl WASM loaded successfully.');
    } else {
      _capturedGlobalThis._dilithium3_step = 'globals_not_registered';
      console.error('[Quantaureum] Dilithium3 WASM loaded but globals not registered.');
    }
  } catch (e) {
    _capturedGlobalThis._dilithium3_step = 'error:' + (e && e.message ? e.message : String(e));
    console.error('[Quantaureum] Failed to load Dilithium3 circl WASM:', e);
  }
})();
